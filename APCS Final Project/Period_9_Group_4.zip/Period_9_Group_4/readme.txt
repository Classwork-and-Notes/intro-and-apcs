Group Members: Kristy Chen, Boying Tang, Tina Zheng

Description:
The project is supposed to help with long term learning by creating notecards and testing your knowledge of the material. You input the terms and definitions first and the program offers you the choice of flashcards or a test. 

Potential Bugs:
- After entering your name, if the folder doesn't exist, it will print  Errorjava.io.IOexception, however the directories and files will still be made. 
- If you enter your full name when prompted to enter your first name, the program will skip your answer to the last name, but it will still work fine.  
- You can exit from the enter term section of adding notes, but you shouldn't otherwise there will be an unequal number of terms and definitions.
- After adding notes, and then running flashcard or test will result in an extra line of "nothing entered" being printed. This however has not been shown to affect the outcome.
- IF you have OCD, please be aware of using flashcards.

Compiling Instructions:
Just compile Driver.java.

How to:
The program should prompt you to enter your first and last name, which will be used to create a directory with First_Last as its name if the directory does not exist. In addition, it will create subjects folder within that directory and two text files within each subject folder. Then you will be prompted to choose what subject you would like to study. When inputting the subject you have to follow the same spelling and capitalization we provided. After you  answer the prompt, you will be asked if you would like to take a test, add notes, or to see flashcards. Please note that you must add notes first before taking a test or using flashcards.

Files in the .zip archive:
-This readme.txt file
-Driver.java
-Subjects.java
